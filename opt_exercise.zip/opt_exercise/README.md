# Simple Git Test #

This repository is designed to demonstrate the power of Git through a simple task:
You are to get a **working** version of the `index.html` file.
A working version is one that does not include any 'TODO' strings and looks "complete".


##The catch:##
You are not to use a text editor of any sort.
Instead, you can and **must** use Git commands (or the Git GUI) to pick and 
choose the correct versions of the files from the repository history.
